#include "render/wallpaper_renderer.h"

#include "core/log.h"
#include "render/backend/render_backend.h"
#include "render/core/texture_manager.h"
#include "render/render_target.h"

#include <chrono>
#include <format>
#include <stdexcept>
#include <utility>

namespace {

  constexpr Logger kLog("wallpaper-render");
  constexpr float kSlowWallpaperRenderOperationDebugMs = 50.0F;
  constexpr float kSlowWallpaperRenderOperationWarnMs = 1000.0F;
  constexpr float kMinimumPostProcessAlpha = 0.001F;

  float elapsedSince(std::chrono::steady_clock::time_point start) {
    return std::chrono::duration<float, std::milli>(std::chrono::steady_clock::now() - start).count();
  }

  template <typename... Args>
  void logSlowWallpaperRenderOperation(float ms, std::format_string<Args...> fmt, Args&&... args) {
    if (ms >= kSlowWallpaperRenderOperationWarnMs) {
      kLog.warn(fmt, std::forward<Args>(args)...);
    } else if (ms >= kSlowWallpaperRenderOperationDebugMs) {
      kLog.debug(fmt, std::forward<Args>(args)...);
    }
  }

} // namespace

WallpaperRenderer::WallpaperRenderer() = default;

WallpaperRenderer::~WallpaperRenderer() { cleanup(); }

void WallpaperRenderer::bind(GlSharedContext& shared, wl_surface* surface) {
  cleanup();

  if (surface == nullptr) {
    throw std::runtime_error("wallpaper renderer requires a valid Wayland surface");
  }

  m_surface = surface;
  m_backend = createDefaultRenderBackend();
  m_backend->initialize(shared);
  m_target = std::make_unique<RenderTarget>();
  m_target->create(surface, *m_backend);
}

void WallpaperRenderer::makeCurrent() {
  if (!m_graphicsResetPending && m_backend != nullptr && m_target != nullptr && m_target->isReady()) {
    m_backend->makeCurrent(*m_target);
  }
}

void WallpaperRenderer::resize(
    std::uint32_t bufferWidth, std::uint32_t bufferHeight, std::uint32_t logicalWidth, std::uint32_t logicalHeight
) {
  if (bufferWidth == 0 || bufferHeight == 0) {
    return;
  }

  if (m_surface == nullptr || m_backend == nullptr || m_target == nullptr) {
    throw std::runtime_error("wallpaper renderer is not bound");
  }

  m_target->setLogicalSize(logicalWidth, logicalHeight);
  m_target->resize(bufferWidth, bufferHeight);
  if (!m_target->isReady()) {
    throw std::runtime_error("wallpaper renderer failed to create render target");
  }

  makeCurrent();

  m_bufferWidth = bufferWidth;
  m_bufferHeight = bufferHeight;
  m_logicalWidth = logicalWidth;
  m_logicalHeight = logicalHeight;

  m_backend->setViewport(bufferWidth, bufferHeight);
}

void WallpaperRenderer::render() {
  if (m_graphicsResetPending || m_backend == nullptr || m_target == nullptr || !m_target->isReady() || m_tex1 == 0) {
    return;
  }

  const auto totalStart = std::chrono::steady_clock::now();
  makeCurrent();
  const auto drawStart = std::chrono::steady_clock::now();
  m_backend->setViewport(m_bufferWidth, m_bufferHeight);
  m_backend->clear(rgba(0.0F, 0.0F, 0.0F, 1.0F));
  m_backend->setBlendMode(RenderBlendMode::StraightAlpha);

  auto sw = static_cast<float>(m_logicalWidth);
  auto sh = static_cast<float>(m_logicalHeight);

  // If no second texture, just draw the first using fade at progress 0
  TextureId tex2 = (m_tex2 != 0) ? m_tex2 : m_tex1;
  float progress = (m_tex2 != 0) ? m_progress : 0.0F;

  m_backend->drawWallpaper(
      WallpaperDrawParams{
          .transition = m_transition,
          .from =
              {.kind = WallpaperSourceKind::Image, .texture = m_tex1, .imageWidth = m_imgW1, .imageHeight = m_imgH1},
          .to = {.kind = WallpaperSourceKind::Image, .texture = tex2, .imageWidth = m_imgW2, .imageHeight = m_imgH2},
          .surfaceWidth = sw,
          .surfaceHeight = sh,
          .quadWidth = sw,
          .quadHeight = sh,
          .progress = progress,
          .fillMode = static_cast<float>(m_fillMode),
          .params = m_params,
          .fillColor = m_fillColor,
      }
  );

  float ms = elapsedSince(drawStart);
  logSlowWallpaperRenderOperation(
      ms, "wallpaper draw took {:.1F}ms ({}x{} logical, {}x{} buffer)", ms, m_logicalWidth, m_logicalHeight,
      m_bufferWidth, m_bufferHeight
  );

  if (m_backend != nullptr) {
    const auto swapStart = std::chrono::steady_clock::now();
    m_backend->endFrame(*m_target);
    ms = elapsedSince(swapStart);
    logSlowWallpaperRenderOperation(
        ms, "wallpaper swap took {:.1F}ms ({}x{} logical, {}x{} buffer)", ms, m_logicalWidth, m_logicalHeight,
        m_bufferWidth, m_bufferHeight
    );
  }
  ms = elapsedSince(totalStart);
  logSlowWallpaperRenderOperation(ms, "wallpaper render took {:.1F}ms total", ms);
}

void WallpaperRenderer::renderToFramebuffer(const RenderFramebuffer& target) {
  if (m_graphicsResetPending
      || m_backend == nullptr
      || m_target == nullptr
      || !m_target->isReady()
      || m_tex1 == 0
      || !target.valid()) {
    return;
  }

  const auto totalStart = std::chrono::steady_clock::now();
  makeCurrent();
  const auto drawStart = std::chrono::steady_clock::now();
  m_backend->bindFramebuffer(target);
  m_backend->setViewport(m_bufferWidth, m_bufferHeight);
  m_backend->clear(rgba(0.0F, 0.0F, 0.0F, 1.0F));
  m_backend->setBlendMode(RenderBlendMode::StraightAlpha);

  auto sw = static_cast<float>(m_logicalWidth);
  auto sh = static_cast<float>(m_logicalHeight);

  TextureId tex2 = (m_tex2 != 0) ? m_tex2 : m_tex1;
  float progress = (m_tex2 != 0) ? m_progress : 0.0F;

  m_backend->drawWallpaper(
      WallpaperDrawParams{
          .transition = m_transition,
          .from =
              {.kind = WallpaperSourceKind::Image, .texture = m_tex1, .imageWidth = m_imgW1, .imageHeight = m_imgH1},
          .to = {.kind = WallpaperSourceKind::Image, .texture = tex2, .imageWidth = m_imgW2, .imageHeight = m_imgH2},
          .surfaceWidth = sw,
          .surfaceHeight = sh,
          .quadWidth = sw,
          .quadHeight = sh,
          .progress = progress,
          .fillMode = static_cast<float>(m_fillMode),
          .params = m_params,
          .fillColor = m_fillColor,
      }
  );
  float ms = elapsedSince(drawStart);
  logSlowWallpaperRenderOperation(
      ms, "wallpaper framebuffer draw took {:.1F}ms ({}x{} logical, {}x{} buffer)", ms, m_logicalWidth, m_logicalHeight,
      m_bufferWidth, m_bufferHeight
  );
  ms = elapsedSince(totalStart);
  logSlowWallpaperRenderOperation(ms, "wallpaper framebuffer render took {:.1F}ms total", ms);
  // No eglSwapBuffers — caller is responsible for presentation
}

void WallpaperRenderer::renderBackdropFrame(
    RenderFramebuffer& target, RenderFramebuffer& scratch, const BackdropPostProcessOptions& options
) {
  if (m_backend == nullptr || !target.valid()) {
    return;
  }

  renderBackdropContent(target, scratch, options);
  presentTexture(target.colorTexture());
}

void WallpaperRenderer::renderBackdropContent(
    RenderFramebuffer& target, RenderFramebuffer& scratch, const BackdropPostProcessOptions& options
) {
  if (m_backend == nullptr || !target.valid()) {
    return;
  }

  renderToFramebuffer(target);

  if (options.blurRadius >= 0.5F && options.blurRounds > 0) {
    if (!scratch.valid()) {
      return;
    }
    blur(target, scratch, options.blurRadius, options.blurRounds);
  }

  if (options.tintIntensity > kMinimumPostProcessAlpha) {
    tint(target, options.tintColor, options.tintIntensity);
  }
}

void WallpaperRenderer::presentTexture(TextureId texture) {
  if (m_graphicsResetPending
      || m_backend == nullptr
      || m_target == nullptr
      || !m_target->isReady()
      || texture == TextureId{}) {
    return;
  }

  blitToSurface(texture);
  swapBuffers();
}

void WallpaperRenderer::invalidateGpuResources() {
  if (m_backend != nullptr) {
    m_backend->invalidateGpuResources();
  }
}

void WallpaperRenderer::prepareForGraphicsReset() noexcept {
  if (m_backend == nullptr) {
    return;
  }
  m_backend->abandonAfterGraphicsReset();
  m_graphicsResetPending = true;
}

void WallpaperRenderer::restoreAfterGraphicsReset(GlSharedContext& shared) {
  // Mirrors prepareForGraphicsReset: an unbound renderer was never torn down, so it has
  // nothing to restore and never set m_graphicsResetPending.
  if (m_backend == nullptr) {
    return;
  }
  m_backend->initialize(shared);
  m_backend->textureManager().probeExtensions();
  if (m_bufferWidth != 0 && m_bufferHeight != 0) {
    m_backend->setViewport(m_bufferWidth, m_bufferHeight);
  }
}

void WallpaperRenderer::blur(RenderFramebuffer& target, RenderFramebuffer& scratch, float radius, int rounds) {
  if (m_backend == nullptr || !target.valid() || !scratch.valid() || radius < 0.5F || rounds <= 0) {
    return;
  }

  makeCurrent();
  m_backend->setViewport(target.width(), target.height());
  m_backend->setBlendMode(RenderBlendMode::Disabled);

  for (int round = 0; round < rounds; ++round) {
    m_backend->bindFramebuffer(scratch);
    m_backend->drawFramebufferBlur(target.colorTexture(), target.width(), target.height(), 1.0F, 0.0F, radius);

    m_backend->bindFramebuffer(target);
    m_backend->drawFramebufferBlur(scratch.colorTexture(), scratch.width(), scratch.height(), 0.0F, 1.0F, radius);
  }
}

void WallpaperRenderer::tint(RenderFramebuffer& target, Color color, float intensity) {
  if (m_backend == nullptr || !target.valid() || intensity <= kMinimumPostProcessAlpha) {
    return;
  }

  makeCurrent();
  m_backend->bindFramebuffer(target);
  m_backend->setViewport(target.width(), target.height());
  m_backend->setBlendMode(RenderBlendMode::StraightAlpha);
  m_backend->drawFullscreenTint(rgba(color.r, color.g, color.b, intensity));
}

void WallpaperRenderer::blitToSurface(TextureId texture) {
  if (m_backend == nullptr || m_target == nullptr || !m_target->isReady() || texture == 0) {
    return;
  }

  makeCurrent();
  m_backend->bindDefaultFramebuffer();
  m_backend->setViewport(m_bufferWidth, m_bufferHeight);
  m_backend->setBlendMode(RenderBlendMode::Disabled);
  m_backend->clear(rgba(0.0F, 0.0F, 0.0F, 0.0F));
  // Offscreen framebuffers use GL convention (Y=0 at bottom), while the
  // window surface uses top-left logical coordinates.
  m_backend->drawFullscreenTexture(texture, true);
}

void WallpaperRenderer::swapBuffers() {
  if (m_backend == nullptr || m_target == nullptr || !m_target->isReady()) {
    return;
  }

  const auto start = std::chrono::steady_clock::now();
  m_backend->endFrame(*m_target);
  const float ms = elapsedSince(start);
  logSlowWallpaperRenderOperation(
      ms, "wallpaper swap took {:.1F}ms ({}x{} logical, {}x{} buffer)", ms, m_logicalWidth, m_logicalHeight,
      m_bufferWidth, m_bufferHeight
  );
}

std::unique_ptr<RenderFramebuffer> WallpaperRenderer::createFramebuffer(std::uint32_t width, std::uint32_t height) {
  if (m_graphicsResetPending || m_backend == nullptr || width == 0 || height == 0) {
    return nullptr;
  }
  makeCurrent();
  return m_backend->createFramebuffer(width, height);
}

void WallpaperRenderer::setTransitionState(
    TextureId tex1, TextureId tex2, float imgW1, float imgH1, float imgW2, float imgH2, float progress,
    WallpaperTransition transition, WallpaperFillMode fillMode, const TransitionParams& params
) {
  m_tex1 = tex1;
  m_tex2 = tex2;
  m_imgW1 = imgW1;
  m_imgH1 = imgH1;
  m_imgW2 = imgW2;
  m_imgH2 = imgH2;
  m_progress = progress;
  m_transition = transition;
  m_fillMode = fillMode;
  m_params = params;
}

void WallpaperRenderer::cleanup() {
  if (m_backend != nullptr) {
    m_backend->makeCurrentNoSurface();
  }

  if (m_target != nullptr) {
    m_target->destroy();
    m_target.reset();
  }

  if (m_backend != nullptr) {
    m_backend->cleanup();
    m_backend.reset();
  }

  m_surface = nullptr;
  m_bufferWidth = 0;
  m_bufferHeight = 0;
  m_logicalWidth = 0;
  m_logicalHeight = 0;
}
